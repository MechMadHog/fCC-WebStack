import Home from './pages/Home.jsx'
import HelloJsx from './components/HelloJsx.jsx'
import styles from './styles/Button.module.css'

export default function App() {
  return <h1>Hello JSX!</h1>;
}

