export const upper = (s) => String(s).toUpperCase()
