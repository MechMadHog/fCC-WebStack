export default function HelloJsx() {
  const JSX = <h2>Hello JSX!</h2>
  return JSX
}