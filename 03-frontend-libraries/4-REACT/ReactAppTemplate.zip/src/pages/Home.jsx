export default function Home() {
  return <p>Welcome. Start in <code>components/HelloJsx.jsx</code>.</p>
}
